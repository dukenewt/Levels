package com.example.level_up_tasks

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
